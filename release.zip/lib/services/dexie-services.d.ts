export default class DexieServices {
    private config;
    private listOps;
    addLastModifiedInfo(item: any): Promise<unknown>;
    addBulkDataToIndexedDB(data: any): Promise<unknown>;
    getMasterInfo(): Promise<unknown>;
    getItemByID(itemID: number): Promise<unknown>;
    addListItem(id: any, salesdata: any): Promise<unknown>;
    udpdatesListItem(id: any, salesdata: any): Promise<unknown>;
    addupdateItems(items: any): void;
    getTableSchema(url: string): Promise<unknown>;
    createDBTable(tableSchema: any, db: any): Promise<unknown>;
    addBulkDataToIndexedDBTable(data: any, tableName: any, db: any): Promise<unknown>;
    addListLastModifiedInfo(item: any, db: any, tableName: any): Promise<unknown>;
}
//# sourceMappingURL=dexie-services.d.ts.map