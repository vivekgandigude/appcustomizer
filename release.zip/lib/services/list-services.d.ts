import "@pnp/sp/lists";
import "@pnp/sp/items";
export declare class ListOperations {
    private config;
    getLatestListItem(url: any, listName: any): Promise<unknown>;
    getListItems(url: any): Promise<unknown>;
    getListData(url: any, listName: any): Promise<unknown>;
    getConfigListNames(url: any): Promise<unknown>;
    getConfigListColumns(url: any): Promise<unknown>;
    getLatestItems(dateValue: any, url: any): Promise<unknown>;
    getLastModifiedItemInfo(url: any): Promise<unknown>;
}
//# sourceMappingURL=list-services.d.ts.map