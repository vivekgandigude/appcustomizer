import Dexie from "dexie";
declare const masterdb: Dexie;
export default masterdb;
//# sourceMappingURL=masterinfo.d.ts.map