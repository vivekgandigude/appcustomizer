import Dexie from "dexie";
declare const empdb: Dexie;
export default empdb;
//# sourceMappingURL=empdatabase.d.ts.map