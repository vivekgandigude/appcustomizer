declare const styles: {
    appCustomHeaderFooter: string;
    bottom: string;
};
export default styles;
//# sourceMappingURL=GileadsamplefooterApplicationCustomizer.module.scss.d.ts.map