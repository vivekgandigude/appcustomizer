import { BaseApplicationCustomizer } from "@microsoft/sp-application-base";
export interface IGileadsamplefooterApplicationCustomizerProperties {
    Bottom: string;
}
/** A Custom Action which can be run during execution of a Client Side Application */
export default class GileadsamplefooterApplicationCustomizer extends BaseApplicationCustomizer<IGileadsamplefooterApplicationCustomizerProperties> {
    private _bottomPlaceholderFooter;
    private url;
    onInit(): Promise<void>;
    private _renderPlaceHoldersHeaderandFooter;
    private _onDispose;
}
//# sourceMappingURL=GileadsamplefooterApplicationCustomizer.d.ts.map