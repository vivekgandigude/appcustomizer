export default function Load(url: any): void;
//# sourceMappingURL=serviceworker.d.ts.map