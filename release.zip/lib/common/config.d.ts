export default class Config {
    LISTNAME: string;
    CONFIGLIST: string;
    LISTNAMESKEY: string;
    INDEXEDDBNAME: string;
    LATESTRECORDTABLE: string;
    KEYCOLUMNNAME: string;
}
//# sourceMappingURL=config.d.ts.map