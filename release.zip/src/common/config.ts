export default class Config {
  public LISTNAME = "SalesRecords";
  public CONFIGLIST = "Config";
  public LISTNAMESKEY = "ListNames";
  public INDEXEDDBNAME = "DevDB";
  public LATESTRECORDTABLE="latestrecords";
  public KEYCOLUMNNAME = "Title";
}
