/* tslint:disable */
require("./GileadsamplefooterApplicationCustomizer.module.css");
const styles = {
  appCustomHeaderFooter: 'appCustomHeaderFooter_8609aded',
  bottom: 'bottom_8609aded'
};

export default styles;
/* tslint:enable */