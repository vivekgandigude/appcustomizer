declare interface IGileadsamplefooterApplicationCustomizerStrings {
  Title: string;
}

declare module 'GileadsamplefooterApplicationCustomizerStrings' {
  const strings: IGileadsamplefooterApplicationCustomizerStrings;
  export = strings;
}
