define([], function() {
  return {
    "Title": "GileadsamplefooterApplicationCustomizer"
  }
});